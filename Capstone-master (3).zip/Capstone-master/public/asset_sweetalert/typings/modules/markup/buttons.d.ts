export declare const buttonMarkup: string;
